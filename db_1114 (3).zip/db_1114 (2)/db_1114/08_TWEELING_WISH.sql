---------------------------------------- WISH TABLE START ---------------------------------------
--update 11-13
--테이블 추가 및 생성

CREATE TABLE WISH(
    USER_NO NUMBER NOT NULL,
    PRODUCT_NO NUMBER NOT NULL,
    FOREIGN KEY (USER_NO) REFERENCES MEMBER (USER_NO),
    FOREIGN KEY (PRODUCT_NO) REFERENCES PRODUCT (PRODUCT_NO)
);

COMMENT ON COLUMN CART.USER_NO IS '회원번호';
COMMENT ON COLUMN CART.PRODUCT_NO IS '상품번호';




commit;
---------------------------------------- WISH TABLE END ---------------------------------------