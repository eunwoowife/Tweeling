---------------------------------------------- CART TABLE START ---------------------------------------------

DROP TABLE CART;
DROP SEQUENCE SEQ_CNO;

CREATE TABLE CART(
    USER_NO NUMBER NOT NULL,
    PRODUCT_NO NUMBER NOT NULL,
    PRODUCT_QUANTITY NUMBER NOT NULL,
    FOREIGN KEY (USER_NO) REFERENCES MEMBER (USER_NO),
    FOREIGN KEY (PRODUCT_NO) REFERENCES PRODUCT (PRODUCT_NO)
);

COMMENT ON COLUMN CART.USER_NO IS '회원번호';
COMMENT ON COLUMN CART.PRODUCT_NO IS '상품번호';
COMMENT ON COLUMN CART.PRODUCT_QUANTITY IS '상품개수';


---------------------------------------------- CART TABLE END ---------------------------------------------
commit;