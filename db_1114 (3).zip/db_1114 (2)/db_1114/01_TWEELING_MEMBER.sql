----------------------------------------------- MEMBER TABLE START -----------------------------------------------

DROP TABLE MEMBER CASCADE CONSTRAINTS;
DROP SEQUENCE SEQ_MNO;

CREATE SEQUENCE SEQ_MNO
NOCACHE;

CREATE TABLE MEMBER(
    USER_NO NUMBER PRIMARY KEY,
    USER_ID VARCHAR2(30) NOT NULL UNIQUE,
    USER_PWD VARCHAR2(100) NOT NULL,
    USER_NAME VARCHAR2(40) NOT NULL,
    USER_NICKNAME  VARCHAR2(30) NOT NULL UNIQUE,
    USER_PHONE VARCHAR2(13) NOT NULL,
    USER_EMAIL VARCHAR2(100) NOT NULL,
    USER_GENDER VARCHAR2(1) NOT NULL,
    USER_ADDRESS VARCHAR2(100) NOT NULL,
    USER_BDAY DATE NOT NULL,
    USER_BIAS VARCHAR2(30),
    USER_ENROLLDATE DATE DEFAULT SYSDATE,
    USER_POINT NUMBER DEFAULT 0 NOT NULL,
    USER_STATUS VARCHAR2(1) DEFAULT 'Y' CHECK (USER_STATUS IN('Y', 'N')),
    ADMIN_STATUS VARCHAR2(1) DEFAULT 'N' CHECK (ADMIN_STATUS IN('Y', 'N'))
);
-- 코멘트 추가
COMMENT ON COLUMN MEMBER.USER_NO IS '회원번호';
COMMENT ON COLUMN MEMBER.USER_ID IS '회원아이디';
COMMENT ON COLUMN MEMBER.USER_PWD IS '회원비밀번호';
COMMENT ON COLUMN MEMBER.USER_NAME IS '회원이름';
COMMENT ON COLUMN MEMBER.USER_NICKNAME IS '회원닉네임';
COMMENT ON COLUMN MEMBER.USER_PHONE IS '전화번호';
COMMENT ON COLUMN MEMBER.USER_EMAIL IS '이메일';
COMMENT ON COLUMN MEMBER.USER_GENDER  IS '성별';
COMMENT ON COLUMN MEMBER.USER_ADDRESS IS '주소';
COMMENT ON COLUMN MEMBER.USER_BDAY IS '생일';
COMMENT ON COLUMN MEMBER.USER_BIAS IS '관심셀럽';
COMMENT ON COLUMN MEMBER.USER_ENROLLDATE IS '회원가입일';
COMMENT ON COLUMN MEMBER.USER_POINT IS '포인트적립';
COMMENT ON COLUMN MEMBER.USER_STATUS IS '회원상태(Y/N)';
COMMENT ON COLUMN MEMBER.ADMIN_STATUS IS '관리자여부(Y/N)';


DELETE MEMBER;
-- 더미 데이터 추가
-- 관리자 둘
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'admin', '1234', '홍길동', '관리자', '010-1111-2222','admin@kh.or.kr','F','서울시 강남구 역삼동', '1999-10-31', '와돈위', SYSDATE, DEFAULT, 'Y', 'Y');
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'admin02', '1234', '어문경', '관리자02', '010-7777-7777','admin02@kh.or.kr','M','본가는 김포', '1990-01-11', '와돈위', SYSDATE, DEFAULT, 'Y', 'Y');
-- 일반 사용자 20명
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user01', '1111', '차은우','얼굴천재', '010-1111-4444','user01@kh.or.kr','M','서울시 강남구 역삼동', '1997-11-11','두아리파', SYSDATE, 0, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user02', '2222', '배주현','은우뷘', '010-1111-3333','user02@kh.or.kr','F','고양시 일산동구 장항동', '1996-10-22','저스틴', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user03', '3333', '김병주','김타타', '010-2222-3333','user03@kh.or.kr','F','인천광역시 중구 참외전로', '1996-10-23','테일러스위프트', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user04', '4444', '이민경','아리짱', '010-2222-2222','user04@kh.or.kr','F','서울시 강서구 네발산동', '1994-10-22','아리아나그란데', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user05', '5555', '김병철','병쪽이', '010-2222-4444','user05@kh.or.kr','M','인천광역시 연수구 선학로', '1988-10-22','dojacat', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user06', '6666', '홍진휘','홍선생', '010-2222-3333','user06@kh.or.kr','M','서울시 어딘가 모르는곳', '1995-10-22','테일러스위프트', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user07', '7777', '노윤석','노선생', '010-2222-3333','user07@kh.or.kr','M','서울시 어딘가 모르는곳', '1995-10-22','아리아나그란데', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user08', '8888', '오하늘','스카이', '010-3333-1111','user08@kh.or.kr','M','서울시 하늘공원', '1995-10-22','와돈위', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user09', '9999', '조진희','지니여왕', '010-3333-2222','user09@kh.or.kr','F','서울시 강서구 세발산동', '1995-10-22','저스틴', SYSDATE, 100, 'Y', 'N');
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user10', '0000', '최정혁','최최최', '010-3333-3333','user10@kh.or.kr','M','서울시 어딘가 모르는곳', '1995-10-22','두아리파', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user11', '1111', '박유리','글래스', '010-3333-4444','user11@kh.or.kr','F','서울시 글래스타운', '1995-10-22','아리아나그란데', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user12', '2222', '김선경','김선생', '010-3333-5555','user12@kh.or.kr','M','서울시 시크릿타운', '1995-10-22','와돈위', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user13', '3333', '오상희','오삼이', '010-3333-6666','user13@kh.or.kr','F','서울시 학원 앞', '1995-10-22','dojacat', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user14', '4444', '유재석','유반장', '010-4444-1111','user14@kh.or.kr','F','서울시 어딘가 모르는곳', '1995-10-22','두아리파', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user15', '5555', '박명수','바다의왕자', '010-4444-2222','user15@kh.or.kr','F','서울시 어딘가 모르는곳', '1995-10-22','아리아나그란데', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user16', '6666', '노홍철','노찌롱', '010-4444-3333','user16@kh.or.kr','F','서울시 어딘가 모르는곳', '1995-10-22','와돈위', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user17', '7777', '정형돈','뚱보', '010-4444-4444','user17@kh.or.kr','F','서울시 어딘가 모르는곳', '1995-10-22','저스틴', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user18', '8888', '정준하','뚱뚱보', '010-4444-5555','user18@kh.or.kr','F','서울시 어딘가 모르는곳', '1995-10-22','테일러스위프트', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user19', '9999', '하동훈','꼬마', '010-4444-6666','user19@kh.or.kr','F','서울시 어딘가 모르는곳', '1995-10-22','dojacat', SYSDATE, 100, 'Y', 'N'); 
INSERT INTO MEMBER VALUES (SEQ_MNO.NEXTVAL, 'user20', '0000', '길성준','길', '010-4444-7777','user20@kh.or.kr','F','서울시 어딘가 모르는곳', '1995-10-22','두아리파', SYSDATE, 100, 'Y', 'N'); 
------------------------------------------------ MEMBER TABLE END ------------------------------------------------
commit;