INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 1, 'JUSTICE STANDARD CD', 'Justin Bieber', 5, 
'TRACKLIST:
1. 2 MUCH
2. DESERVE YOU.
3. AS I AM FEAT. KHALID
4. OFF MY FACE
5. HOLY FEAT. CHANCE THE RAPPER
6. UNSTABLE FEAT. THE KID LAROI
7. MLK INTERLUDE
8. DIE FOR YOU FEAT. DOMINIC FIKE
9. HOLD ON
10. SOMEBODY 
11. GHOST
12. PEACHES FEAT. DANIEL CAESAR AND GIVEON
13. LOVE YOU DIFFERENT FEAT. BEAM
14. LOVED BY YOU FEAT. BURNA BOY
15. ANYONE
16. LONELY W/BENNY BLANCO', 
24000, 'JUSTICE STANDARD CD', SYSDATE, 'Y');
 
INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 2, 'Midnights Blue Tie Dye Hoodie', 'Taylor Swift', 10, 
'Blue cloud tie dye hoodie featuring Taylor Swift Midnights album cover photo and "Friday Meet me at midnight" printed on front and album tracklist printed on back.
80% cotton, 20% polyester', 
70000, 
'Taylor Swift®
©2022 TAS Rights Management LLC
Used By Permission. All Rights Reserved.', 
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 3, 'R.E.M. Eau de Parfum', 'Ariana Grande', 18,
'Fragrance Family
-Floral
Scent Type
-Musk
Key Notes
-Top: Quince / Fig / Salted Caramel / Marshmallow
-Heart: Pear Blossom / Lavender Blossom
-Base: Tonka Bean / White Musk / Sandalwood',
60000,
'Apply to pulse points: wrist and chest and neck.',
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 4, 'FUTURE NOSTALGIA CLEAR TOTE BAG', 'Dua Lipa', 6,
'Future Nostalgia cherub design printed on a clear tote bag. 12"W x 12"H x 8"D.',
40000,
NULL,
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 4, 'Beaded Bracelet', 'Why Don''t We', 21,
'Beaded Bracelet features beads on a 2 inner diameter, stretch bracelet made of glass, plastic and alloy.',
12000,NULL,
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 3, '10-Piece Brush Set with Bag', 'Doja Cat', 32,
'A tenpiece face and eye brush set. Create Doja Catworthy looks with the BH Cosmetics x Doja Cat Metamorphosis 10 Piece Brush Set with Bag.
With ten face and eye brushes to help you create killer looks;
the brushes feature reflective gold chrome bobble handles and bright twotoned synthetic bristles;
plus a matching transparent jelly zipper bag. 
Vegan Cruelty freeSet Includes: 
A highlighter brush 
A powder brush 
A blusher brush 
An angled contour brush 
A round eyeshadow packer brush 
An angled crease eyeshadow brush 
A fluffy blending eyeshadow brush 
A tapered crease eyeshadow brush 
An angled eyeliner brush 
A small detail brush',
40000,'BH COSMETICS X DOJA CAT METAMORPHOSIS 10 PIECE BRUSH SET WITH BAG',
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 3, 'REFLECTION HAND MIRROR', 'Doja Cat', 15,
'A hand-held mirror.
Make sure your looks are always flawless with the BH Cosmetics x Doja Cat Reflection Hand Mirror. 
With a gold finish and a round mirror, the accessory is the ultimate haul for applying makeup and skincare at-home and on-the-go..',
8000,'BH COSMETICS X DOJA CAT REFLECTION HAND MIRROR',
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 2, 'PEACHES T-SHIRT', 'Justin Bieber', 9,
'Solid colors: 100% Cotton; Heather Grey: 90% Cotton, 10% Polyester; All Other Heathers: 50% Cotton, 50% Polyester
Imported
Machine wash cold with like colors, dry low heat
Authentic Licensed Bravado Justin Bieber Merchandise
Legal and Official Justin Bieber Merchandise in partnership with Bravado International Group, a Universal Music Group Company; 2022
Lightweight, Classic fit, Double-needle sleeve and bottom hem',
36000,'SCREENPRINTED FRONT GRAPHIC.',
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 1, 'MIDNIGHTS [MOONSTONE BLUE EDITION] CASSETTE', 'Taylor Swift', 53,
'Released: 10/21/2022
Format: Cassette',
24000,NULL,
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 2, 'FUTURE NOSTALGIA SWEATPANTS', 'Dua Lipa', 12,
'Future Nostalgia tour sweatpants by Pangaia in black.
Made with 100% responsibly sourced, recycled materials.
Official Future Nostalgia Tour 2022 merchandise.',
86000,NULL,
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 4, 'Love Back Crew Socks', 'Why Don''t We', 34,
'feature "Love Black" and "WDW" in black on a pair of white cotton crew one size fits most socks.',
22000,NULL,
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 4, 'sweetener world tour hat', 'Ariana Grande', 28,
'embroidered front and side graphics.',
30000,NULL,
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 1, 'The Good Times And The Bad Ones CD', 'Why Don''t We', 22,
'The Good Times And The Bad Ones CD. Not Signed.',
11000,NULL,
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 2, 'HEAVY METAL T-SHIRT II', 'Doja Cat', 14,
'BLACK T-SHIRT WITH “DOJA CAT” AND “PLANET HER” TEXT PRINTED ON FRONT WITH IMAGE.',
37000,NULL,
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 3, 'WONDERSTRUCK Eau de Parfum', 'Taylor Swift', 13,
'Wonderstruck is the first fragrance from the young American pop - country singer Taylor Swift, launched in cooperation with the cosmetic company Elizabeth Arden. 
The perfume is created by Olivier Gillotin of Givaudan.
Wonderstruck is named after the lyrics from the song "Enchanted": "I''m wonderstruck, blushing all the way home," 
which tell about the feeling and the impression you get when you first meet someone you like. T
aylor hopes that her fragrance will be an essential part of many impressions and first meetings.

The fragrance composition is described as a charming gourmand – floral with sparkling fruity tones on a wooden background. 
The top notes are raspberry, dewberry, green tea, freesia and apple blossom.
The heart features sweet vanilla along with sundrenched honeysuckle and white hibiscus.
Notes of golden amber, musk, sandalwood and peach are in the base.

Wonderstruck will be available from October in 50 ml and 100 ml bottles with an accompanying collection for body care.',
63000,'Apply to pulse points: wrist and chest and neck.',
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 2, 'Quarter Zip Fleece (Navy)', 'Why Don''t We', 8,
'The Why Don''t We "Quarter Zip Fleece (Navy)" features a white "Why Don''t We" logo on the top left of the front of the fleece.
This design is on a navy blue unisex quarter zip fleece..',
106000,NULL,
SYSDATE, 'Y');


INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 1, 'FUTURE NOSTALGIA BONUS EDITION 2CD', 'Dua Lipa', 29,
'Tracklisting

Disc 1 Future Nostalgia 

1. Future Nostalgia
2. Don''t Start Now
3. Cool
4. Physical
5. Levitating
6. Pretty Please
7. Hallucinate
8. Love Again
9. Break My Heart
10. Good In Bed
11. Boys Will Be Boys
12. Levitating ft DaBaby


Disc 2 Club Future Nostalgia

1. Future Nostalgia -Joe Goddard Remix.
2. Cool - Jayda G Remix.
3. Good In Bed - Gen Hoshino Remix and Zach Witness Remix.
4. Pretty Please - Midland Refix.
5. Pretty Please - Masters At Work Remix. 
6. Boys Will Be Boys - Zach Witness Remix. Sample Lyn Collins - Think (About It)
7. Love Again - Horse Meat Disco Remix.
8. Break My Heart / Jamiroquai Cosmic Girl. Sample Jamiroquai - Cosmic Girl (Dimitri From Paris Dubwize Remix)
9. Levitating (feat. Madonna and Missy Elliott) - The Blessed Madonna Remix.
10. Hallucinate - Mr Fingers deep stripped mix. 
11. Hallucinate - Paul Woolford Extended Remix.  
12. Love Is Religion - The Blessed Madonna Remix.
13. Don''t Start Now - Yaeji Remix.
14. Physical (feat. Gwen Stefani) - Mark Ronson Remix.
15. Dua Lipa And BLACKPINK - Kiss and Make Up.
16. That Kind Of Woman – Jacques Lu Cont Remix. Sample Stevie Nicks - Stand Back Acapella 
17. Break My Heart - Moodymann Remix.',
17000,NULL,
SYSDATE, 'Y');

INSERT INTO PRODUCT VALUES(SEQ_PNO.NEXTVAL, 4, 'Bejeweled Bracelet', 'Taylor Swift', 0,
'Gold bracelet with adjustable clasp closure and "TS" engraved on charm, featuring 12 gemstones, each representing a Taylor Swift album.

6.3" - 8" long, adjustable clasp
Copper alloy, 18k gold plating, multi colored CZ jewels

Tips for preserving the quality of your bracelet: keep the jewelry dry, remove the bracelet while swimming or taking a shower.
Avoid exposure to water and chemicals such as soaps and hand sanitizer.
Apply perfumes and creams prior to putting on your jewelry.',
37000,'Limit 10 per order.',
SYSDATE, 'Y');

COMMIT;




































------------------------------------------------------------------------------------

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,1,'justiceCD.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,2,'Midnights Blue Tie Dye Hoodie.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,3,'R.E.M. Eau de Parfum.jpg','/resources/product_upfiles/',1);


INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,4,'FUTURE NOSTALGIA CLEAR TOTE BAG.jpg','/resources/product_upfiles/',1);


INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,5,'Beaded Bracelet.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,6,'10-Piece Brush Set with Bag.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,7,'REFLECTION HAND MIRROR.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,8,'PEACHES T-SHIRT.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,9,'MIDNIGHTS CASSETTE.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,10,'NOSTALGIA SWEATPANTS.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,11,'Love Back Crew Socks.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,12,'sweetener world tour hat.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,13,'The Good Times And The Bad Ones CD.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,14,'HEAVY METAL T-SHIRT II.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,15,'WONDERSTRUCK Eau de Parfum.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,16,'Quarter Zip Fleece (Navy).jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,17,'FUTURE NOSTALGIA BONUS EDITION 2CD.jpg','/resources/product_upfiles/',1);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,18,'Bejeweled Bracelet.jpg','/resources/product_upfiles/',1);



COMMIT;




















--------------------------------------------------------------------------
INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,3,'remdetail1.jpg','/resources/product_upfiles/',2);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,3,'remdetail2.jpg','/resources/product_upfiles/',2);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,16,'wonderstruckdetail1.jpg','/resources/product_upfiles/',2);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,14,'heavydetail1.jpg','/resources/product_upfiles/',2);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,6,'10brushdetail1.jpg','/resources/product_upfiles/',2);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,6,'10brushdetail2.jpg','/resources/product_upfiles/',2);

INSERT INTO P_ATTACHMENT(FILE_NO,
			REF_PNO,
			ORIGIN_NAME,
			FILE_PATH,
			FILE_LEVEL)
VALUES(SEQ_PFNO.NEXTVAL,6,'10brushdetail3.jpg','/resources/product_upfiles/',2);

COMMIT;


